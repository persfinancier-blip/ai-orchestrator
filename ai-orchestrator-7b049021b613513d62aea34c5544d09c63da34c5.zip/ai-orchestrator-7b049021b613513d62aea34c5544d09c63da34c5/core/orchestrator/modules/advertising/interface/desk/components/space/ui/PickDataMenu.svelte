<!-- core/orchestrator/modules/advertising/interface/desk/components/space/ui/PickDataMenu.svelte -->
<script lang="ts">
  import type { PeriodMode } from '../types';
  import ColorPickerPopover from './ColorPickerPopover.svelte';

  export let textFields: Array<{ code: string; name: string; kind: 'text' }>;
  export let coordFields: Array<{ code: string; name: string; kind: 'number' | 'date' }>;

  export let selectedEntityFields: string[] = [];
  export let axisX = '';
  export let axisY = '';
  export let axisZ = '';

  export let search = '';

  export let period: PeriodMode = '30 дней';
  export let fromDate = '';
  export let toDate = '';

  export let onAddEntity: (code: string) => void;
  export let onAddCoord: (code: string) => void;
  export let onClose: () => void;

  /**
   * ✅ Цвет для каждого выбранного поля: code -> hex
   * Родитель передаёт bind:entityFieldColors
   */
  export let entityFieldColors: Record<string, string> = {};

  /**
   * ✅ Цвет по умолчанию для новых полей
   */
  export let defaultEntityColor = '#3b82f6';

  type AnyField =
    | { code: string; name: string; kind: 'text' }
    | { code: string; name: string; kind: 'number' | 'date' };

  const kindLabel: Record<string, string> = { text: 'текст', number: 'число', date: 'дата' };

  $: selectedCoordCount = [axisX, axisY, axisZ].filter(Boolean).length;
  $: canAddCoord = selectedCoordCount < 3;

  $: allFields = ([...(textFields ?? []), ...(coordFields ?? [])] as AnyField[]);
  $: q = search.trim().toLowerCase();
  $: filteredFields =
    !q
      ? allFields
      : allFields.filter(
          (f) => (f.name ?? '').toLowerCase().includes(q) || (f.code ?? '').toLowerCase().includes(q)
        );

  $: nameByCode = new Map(allFields.map((f) => [f.code, f.name] as const));
  const chipLabel = (code: string): string => nameByCode.get(code) ?? code;

  // --- per-field color popover state ---
  let isColorOpen = false;
  let activeColorCode: string | null = null;
  let activeColorValue = defaultEntityColor;

  function getFieldColor(code: string): string {
    return entityFieldColors?.[code] ?? defaultEntityColor;
  }

  function setFieldColor(code: string, color: string): void {
    const cleaned = String(color ?? '').trim();
    if (!cleaned) return;
    entityFieldColors = { ...(entityFieldColors ?? {}), [code]: cleaned };
  }

  function deleteFieldColor(code: string): void {
    if (!entityFieldColors?.[code]) return;
    const next = { ...(entityFieldColors ?? {}) };
    delete next[code];
    entityFieldColors = next;
  }

  function openColorFor(code: string): void {
    activeColorCode = code;
    activeColorValue = getFieldColor(code);
    isColorOpen = true;
  }

  function closeColor(): void {
    isColorOpen = false;
    activeColorCode = null;
  }

  function onActiveHexInput(e: Event): void {
    const el = e.currentTarget as HTMLInputElement | null;
    if (!el) return;
    activeColorValue = String(el.value ?? '').trim();
  }

  // ✅ live update: пока поповер открыт — пишем в entityFieldColors, чтобы:
  // - свотч менялся сразу
  // - график перекрашивался сразу (через bind в родителе)
  $: if (isColorOpen && activeColorCode) {
    entityFieldColors = { ...(entityFieldColors ?? {}), [activeColorCode]: activeColorValue };
  }

  // --- selection logic ---
  function toggleText(code: string): void {
    const cleaned = String(code ?? '').trim();
    if (!cleaned) return;

    if (selectedEntityFields.includes(cleaned)) {
      selectedEntityFields = selectedEntityFields.filter((x) => x !== cleaned);
      deleteFieldColor(cleaned);
      return;
    }

    selectedEntityFields = [...selectedEntityFields, cleaned];

    // чтобы свотч был сразу после добавления
    if (!entityFieldColors?.[cleaned]) setFieldColor(cleaned, defaultEntityColor);
  }

  function selectedAxis(code: string): 'x' | 'y' | 'z' | null {
    if (axisX === code) return 'x';
    if (axisY === code) return 'y';
    if (axisZ === code) return 'z';
    return null;
  }

  function removeCoord(code: string): void {
    const ax = selectedAxis(code);
    if (ax === 'x') axisX = '';
    if (ax === 'y') axisY = '';
    if (ax === 'z') axisZ = '';
  }

  function addCoord(code: string): void {
    const cleaned = String(code ?? '').trim();
    if (!cleaned) return;

    if (axisX === cleaned || axisY === cleaned || axisZ === cleaned) return;
    if (!canAddCoord) return;

    if (!axisX) axisX = cleaned;
    else if (!axisY) axisY = cleaned;
    else if (!axisZ) axisZ = cleaned;
  }

  function toggleCoord(code: string): void {
    const cleaned = String(code ?? '').trim();
    if (!cleaned) return;

    if (selectedAxis(cleaned)) {
      removeCoord(cleaned);
      return;
    }

    addCoord(cleaned);
  }

  function isDisabledField(f: AnyField): boolean {
    if (f.kind === 'text') return false;
    if (selectedAxis(f.code)) return false;
    return !canAddCoord;
  }

  function onPick(f: AnyField): void {
    if (isDisabledField(f)) return;
    if (f.kind === 'text') toggleText(f.code);
    else toggleCoord(f.code);
  }
</script>

<div class="menu-pop pick">
  <div class="pick-inner">
    <div class="menu-title">Выбор данных</div>

    <div class="selected-bar">
      <div class="selected-block">
        <div class="selected-title">Выбраны поля</div>

        <div class="chips">
          {#if (selectedEntityFields?.length ?? 0) === 0}
            <span class="empty">ничего</span>
          {:else}
            {#each selectedEntityFields as c (c)}
              <span class="chip">
                <button
                  type="button"
                  class="swatch"
                  aria-label="Цвет поля"
                  style={`background:${getFieldColor(c)};`}
                  on:click|stopPropagation={() => openColorFor(c)}
                ></button>

                <span class="chip-text">{chipLabel(c)}</span>
              </span>
            {/each}
          {/if}
        </div>
      </div>

      <div class="selected-block">
        <div class="selected-title">Оси</div>
        <div class="chips">
          <span class="chip axis">X: {axisX ? chipLabel(axisX) : '—'}</span>
          <span class="chip axis">Y: {axisY ? chipLabel(axisY) : '—'}</span>
          <span class="chip axis">Z: {axisZ ? chipLabel(axisZ) : '—'}</span>
        </div>
      </div>
    </div>

    <div class="row">
      <input class="input" placeholder="Поиск по полям (Ctrl+K)" bind:value={search} />
    </div>

    <div class="sep" />

    <div class="sub">Поля</div>

    <div class="list">
      {#each filteredFields as f (f.code)}
        <button class="item" disabled={isDisabledField(f)} on:click={() => onPick(f)}>
          <span class="name">{f.name}</span>

          <span class="right">
            {#if f.kind !== 'text' && selectedAxis(f.code)}
              <span class="pill">{selectedAxis(f.code)?.toUpperCase()}</span>
            {/if}
            <span class="tag">{kindLabel[f.kind]}</span>
          </span>
        </button>
      {/each}
    </div>

    {#if !canAddCoord}
      <div class="limit">
        Уже выбрано 3 координаты (X/Y/Z). Удалите одну прямо на ребре куба (×), чтобы добавить другую.
      </div>
    {/if}

    {#if isColorOpen}
      <div class="picker-overlay" on:click={closeColor}></div>

      <div class="picker-layer" aria-label="Цвет поля">
        <ColorPickerPopover bind:value={activeColorValue} title="Цвет поля" onClose={closeColor} />

        <div class="active-hex">
          <input class="hex" value={activeColorValue} on:input={onActiveHexInput} />
        </div>
      </div>
    {/if}
  </div>
</div>

<style>
  .pick-inner {
    position: relative;
  }

  .row {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-top: 10px;
  }

  .sep {
    height: 1px;
    background: var(--divider, rgba(226, 232, 240, 0.7));
    margin: 12px 0 8px;
  }

  .sub {
    margin-top: 2px;
    font-size: 12px;
    font-weight: 650;
    color: rgba(15, 23, 42, 0.78);
  }

  .selected-bar {
    margin: 8px 0 10px;
    padding: 10px;
    border-radius: 14px;
    background: rgba(15, 23, 42, 0.04);
    border: 1px solid rgba(15, 23, 42, 0.08);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .selected-block {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .selected-title {
    font-size: 11px;
    font-weight: 800;
    color: rgba(15, 23, 42, 0.7);
  }

  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: center;
  }

  .empty {
    font-size: 12px;
    color: rgba(100, 116, 139, 0.9);
  }

  .chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 700;
    color: rgba(15, 23, 42, 0.86);
    background: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(15, 23, 42, 0.1);
    padding: 6px 10px;
    border-radius: 999px;
    line-height: 1;
    max-width: 100%;
  }

  .chip.axis {
    background: rgba(248, 251, 255, 0.92);
  }

  .chip-text {
    min-width: 0;
    white-space: nowrap;
  }

  .swatch {
    width: 16px;
    height: 16px;
    border-radius: 999px;
    border: 1px solid rgba(15, 23, 42, 0.12);
    cursor: pointer;
    padding: 0;
    flex: 0 0 auto;
  }

  .hex {
    width: 100%;
    border: 1px solid var(--stroke-soft, rgba(15, 23, 42, 0.08));
    background: #ffffff;
    border-radius: 12px;
    padding: 10px 12px;
    font-size: 12px;
    outline: none;
    color: rgba(15, 23, 42, 0.9);
    box-sizing: border-box;
  }

  .hex:focus {
    box-shadow: var(--focus-ring, 0 0 0 4px rgba(15, 23, 42, 0.1));
  }

  .list {
    margin-top: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    max-height: 320px;
    overflow: auto;
    padding-right: 2px;
  }

  .item {
    width: 100%;
    text-align: left;
    border: 1px solid var(--stroke-soft, rgba(15, 23, 42, 0.08));
    background: #ffffff;
    border-radius: 14px;
    padding: 10px 10px;
    display: flex;
    justify-content: space-between;
    gap: 10px;
    cursor: pointer;
    box-sizing: border-box;
    transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease, background 120ms ease;
  }

  .item:hover {
    transform: translateY(-0.5px);
    box-shadow: var(--shadow-btn, 0 10px 26px rgba(15, 23, 42, 0.1));
    border-color: var(--stroke-mid, rgba(15, 23, 42, 0.12));
  }

  .item:disabled {
    opacity: 0.55;
    cursor: not-allowed;
    box-shadow: none;
    transform: none;
  }

  .name {
    font-size: 12px;
    font-weight: 650;
    color: rgba(15, 23, 42, 0.88);
  }

  .right {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }

  .tag {
    font-size: 11px;
    color: rgba(100, 116, 139, 0.9);
  }

  .pill {
    font-size: 11px;
    font-weight: 800;
    color: rgba(15, 23, 42, 0.82);
    background: rgba(15, 23, 42, 0.06);
    border: 1px solid rgba(15, 23, 42, 0.1);
    padding: 4px 8px;
    border-radius: 999px;
    line-height: 1;
  }

  .limit {
    margin-top: 8px;
    font-size: 12px;
    color: rgba(100, 116, 139, 0.95);
    background: #ffffff;
    border: 1px solid var(--stroke-soft, rgba(15, 23, 42, 0.08));
    border-radius: 14px;
    padding: 10px 12px;
    box-sizing: border-box;
  }

  /* overlay только внутри меню */
  .picker-overlay {
    position: absolute;
    inset: 0;
    background: rgba(15, 23, 42, 0.25);
    backdrop-filter: blur(2px);
    z-index: 200;
  }

  .picker-layer {
    position: absolute;
    inset: 0;
    z-index: 201;
    pointer-events: none;
  }

  .picker-layer :global(.picker) {
    position: absolute !important;
    top: 50% !important;
    left: 50% !important;
    right: auto !important;
    transform: translate(-50%, -50%) !important;
    pointer-events: auto;
    max-width: min(92vw, 360px);
  }

  .active-hex {
    position: absolute;
    left: 50%;
    top: calc(50% + 170px);
    transform: translateX(-50%);
    width: min(280px, 92%);
    pointer-events: auto;
    z-index: 202;
  }

  @media (max-height: 560px) {
    .picker-layer :global(.picker) {
      top: 12px !important;
      transform: translate(-50%, 0) !important;
    }
    .active-hex {
      top: 340px;
    }
  }
</style>
