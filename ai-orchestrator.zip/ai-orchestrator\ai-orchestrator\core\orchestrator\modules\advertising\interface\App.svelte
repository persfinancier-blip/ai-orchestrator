<script>
  import AdvertisingDashboard from './components/layout/AdvertisingDashboard.svelte';
</script>

<div class="app">
  <AdvertisingDashboard />
</div>

<style>
  .app {
    height: 100vh;
    overflow: hidden;
  }
</style>